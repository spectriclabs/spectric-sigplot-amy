/*

 File: matfile.js
 Copyright (c) 2012-2017, LGS Innovations Inc., All rights reserved.

 This file is part of SigPlot.

 Licensed to the LGS Innovations (LGS) under one
 or more contributor license agreements.  See the NOTICE file
 distributed with this work for additional information
 regarding copyright ownership.  LGS licenses this file
 to you under the Apache License, Version 2.0 (the
 "License"); you may not use this file except in compliance
 with the License.  You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing,
 software distributed under the License is distributed on an
 "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND, either express or implied.  See the License for the
 specific language governing permissions and limitations
 under the License.
*/
(function(l){"object"===typeof exports&&"undefined"!==typeof module?module.exports=l():"function"===typeof define&&define.amd?define([],l):("undefined"!==typeof window?window:"undefined"!==typeof global?global:"undefined"!==typeof self?self:this).matfile=l()})(function(){return function(){function l(s,t,n){function p(h,q){if(!t[h]){if(!s[h]){var g="function"==typeof require&&require;if(!q&&g)return g(h,!0);if(x)return x(h,!0);g=Error("Cannot find module '"+h+"'");throw g.code="MODULE_NOT_FOUND",g;
}g=t[h]={exports:{}};s[h][0].call(g.exports,function(g){return p(s[h][1][g]||g)},g,g.exports,l,s,t,n)}return t[h].exports}for(var x="function"==typeof require&&require,v=0;v<n.length;v++)p(n[v]);return p}return l}()({1:[function(l,s,t){(function(n){function p(a){a=new Uint8Array(a);if(w)return String.fromCharCode.apply(null,a);for(var f="",d=0;d<a.length;d++)f+=String.fromCharCode(a[d]);return f}function l(a){return 0<=a&&31>a?1<<a:l[a]||(l[a]=Math.pow(2,a))}function s(a,f,d,b){var e=[];new DataView(a,
f,d);if("miINT8"===b)a=new Int8Array(a,f,d);else if("miUINT8"===b)a=new Uint8Array(a,f,d);else if("miINT16"===b)a=new Int16Array(a,f,d);else if("miUINT16"===b)a=new Uint16Array(a,f,d);else if("miINT32"===b)a=new Int32Array(a,f,d);else if("miUINT32"===b)a=new Uint32Array(a,f,d);else if("miDOUBLE"===b)a=new Float64Array(a,f,d);else{window.console.warn("Array data type not supported yet.");return}a.forEach(function(a){e.push(a)});return e}function h(a,f,d,b){var e;switch(f){case "miINT8":e=a.getInt8(d,
b);break;case "miUINT8":e=a.getInt8(d,b);break;case "miINT16":e=a.getInt16(d,b);break;case "miUINT16":e=a.getUint16(d,b);break;case "miINT32":e=a.getInt32(d,b);break;case "miUINT32":e=a.getUint32(d,b);break;case "miSINGLE":e=a.getFloat32(d,b);break;case "miDOUBLE":e=a.getFloat64(d,b);break;case "miINT64":var c;f=Math.pow(2,53);b?(c=4,e=0):(c=0,e=4);c=a.getInt32(d+c,b);a=a.getInt32(d+e,b)+l(32)*c;a>=f?(window.console.info("Int is bigger than JS can represent."),e=Infinity):e=a;break;default:window.console.warn(f+
" not supported at thsi time")}return e}function q(a,f){this.file_name=this.file=null;this.buf=a;if(null!=this.buf){var d=new DataView(this.buf);this.headerStr=p(this.buf.slice(z-1,A));this.datarep=p(this.buf.slice(B-1,C));var b="IM"===this.datarep,e="IM"===this.datarep;this.headerList=this.headerStr.split(",").map(function(a){return a.trim()});this.matfile=this.headerList[0];this.platform=this.headerList[1];this.createdOn=this.headerList[2];this.subsystemOffset=p(this.buf.slice(D-1,E));this.version=
d.getUint16(F-1,b);this.versionName=G[this.version];this.dataType=d.getUint32(H-1,b);this.dataTypeName=r[this.dataType].name;this.arraySize=d.getUint32(I-1,b);var c=J+1,b=d.getUint32(c-1,b),k=r[b].name,b=r[b].size,c=c+4;h(d,k,c-1,e);c+=b;h(d,k,c-1,e);var c=c+b+b,m=d.getUint32(c-1,e),c=c+4,k=r[m].name,m=r[m].size;d.getUint32(c-1,e);var c=c+4,g=h(d,k,c-1,e),c=c+m;1<g&&window.console.warn("Only 1D arrays are currently supported.");h(d,k,c-1,e);c+=b;m=d.getUint32(c-1,e);c+=4;b=0;k=!1;15<m&&(m&=255,k=
!0,b=d.getUint16(c-5,e));m=r[m].name;k||(b=h(d,m,c-1,e),c+=4);p(this.buf.slice(c-1,c+b-1));c+=b+(k?(4-b%4)%4:(8-b%8)%8);this.setData(this.buf,d,c,e)}}function g(a){var f=document.createElement("a");f.href=a;for(var d=f.protocol.replace(":",""),b=f.hostname,e=f.port,c=f.search,k={},m=f.search.replace(/^\?/,"").split("&"),g=m.length,h=0,l;h<g;h++)m[h]&&(l=m[h].split("="),k[l[0]]=l[1]);return{source:a,protocol:d,host:b,port:e,query:c,params:k,file:(f.pathname.match(/\/([^\/?#]+)$/i)||[null,""])[1],hash:f.hash.replace("#",
""),path:f.pathname.replace(/^([^\/])/,"/$1"),relative:(f.href.match(/tps?:\/\/[^\/]+(.+)/)||[null,""])[1],segments:f.pathname.replace(/^\//,"").split("/")}}function t(a,f,d){d=d||1024;var b=0,e=new ArrayBuffer(a.length),c=new Uint8Array(e),k=function(){for(var g=b+d;b<g;b++)c[b]=a.charCodeAt(b)&255;b>=a.length?f(e):setTimeout(k,0)};setTimeout(k,0)}function y(a){this.options=a}navigator.userAgent.match(/(iPad|iPhone|iPod)/i);var z=1,A=116,D=117,E=124,F=125,B=127,C=128,H=129,I=133,J=136;(function(){var a=
new ArrayBuffer(4),f=new Uint32Array(a),a=new Uint8Array(a);f[0]=3735928559;if(239===a[0])return"LE";if(222===a[0])return"BE";throw Error("unknown endianness");})();var G={256:"MAT-file"},r={1:{name:"miINT8",size:1},2:{name:"miUINT8",size:1},3:{name:"miINT16",size:2},4:{name:"miUINT16",size:2},5:{name:"miINT32",size:4},6:{name:"miUINT32",size:4},7:{name:"miSINGLE",size:4},9:{name:"miDOUBLE",size:8},12:{name:"miINT64",size:8},13:{name:"miUINT64",size:8},14:{name:"miMATRIX",size:null},15:{name:"miCOMPRESSED",
size:null},16:{name:"miUTF8",size:null},17:{name:"miUTF16",size:null},18:{name:"miUTF32",size:null}},w=!0;try{var u=new Uint8Array(new ArrayBuffer(4));u[0]=66;u[1]=76;u[2]=85;u[3]=69;"BLUE"!==String.fromCharCode.apply(null,u)&&(w=!1)}catch(K){w=!1}q.prototype={setData:function(a,f,d,b){var e,c=f.getUint32(d-1,b),k=!1;15<c?(c&=255,k=!0,e=f.getUint16(d+1,2,b)):d+=4;var g=r[c].name,c=r[c].size;k||(e=f.getUint32(d-1,b));this.dview=s(a,d+4-1,e/c,g)}};y.prototype={readheader:function(a,f){var d=this,b=
new FileReader,e=a.webkitSlice(0,116);b.onloadend=function(a){return function(e){e.target.error?f(null):(e=new q(b.result,d.options),e.file=a,f(e))}}(a);b.readAsArrayBuffer(e)},read:function(a,f){var d=this,b=new FileReader;b.onloadend=function(a){return function(c){c.target.error?f(null):(c=new q(b.result,d.options),c.file=a,c.file_name=a.name,f(c))}}(a);b.readAsArrayBuffer(a)},read_http:function(a,f){var d=this,b=new XMLHttpRequest;b.open("GET",a,!0);b.responseType="arraybuffer";b.overrideMimeType("text/plain; charset=x-user-defined");
b.onload=function(e){if(4!==b.readyState||200!==b.status&&0!==b.status)f(null);else if(e=null,b.response){e=b.response;e=new q(e,d.options);g(a);var c=g(a);e.file_name=c.file;f(e)}else b.responseText&&t(b.responseText,function(b){b=new q(b,d.options);g(a);var c=g(a);b.file_name=c.file;f(b)})};b.onerror=function(a){f(null)};b.send(null)}};n.MatHeader=n.MatHeader||q;n.MatFileReader=n.MatFileReader||y})(this)},{}]},{},[1])(1)});
